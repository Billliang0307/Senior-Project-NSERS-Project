﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

// Represents a security incident with details, report time, and severity level.
class Incident
{
    // Details of the incident
    public string IncidentDetails { get; set; }
    // Timestamp when the incident was reported
    public DateTime ReportedAt { get; set; }
    // Severity level of the incident
    public string Severity { get; set; }

    // Constructor to initialize a new incident with specified details and severity
    public Incident(string details, string severity)
    {
        IncidentDetails = details; // Set the incident details
        ReportedAt = DateTime.Now; // Capture the current date and time as report time
        Severity = severity; // Set the severity level
    }
}

// Manages the collection and display of reported incidents
class IncidentReportingSystem
{
    // A list to hold all reported incidents
    private List<Incident> incidents;

    // Constructor to initialize the incident reporting system
    public IncidentReportingSystem()
    {
        incidents = new List<Incident>(); // Initialize the list of incidents
    }

    // Reports a new incident with given details and severity
    public void ReportIncident(string details, string severity)
    {
        Incident newIncident = new Incident(details, severity); // Create a new incident
        incidents.Add(newIncident); // Add the new incident to the list
        // Notify user of successful incident report
        Console.WriteLine($"Incident reported successfully at {newIncident.ReportedAt}. Severity: {newIncident.Severity}");
    }

    // Displays all reported incidents
    public void DisplayIncidents()
    {
        if (incidents.Count == 0) // Check if there are no reported incidents
        {
            Console.WriteLine("No incidents reported."); // Inform the user that no incidents have been reported
            return;
        }

        // Loop through each incident in the list and display its details
        foreach (var incident in incidents)
        {
            Console.WriteLine($"Incident Details: {incident.IncidentDetails}\nReported At: {incident.ReportedAt}\nSeverity: {incident.Severity}\n");
        }
    }
}

// Represents a user with a username and password
class User
{
    public string Username { get; set; } // User's username
    public string Password { get; set; } // User's password
}

// Represents feedback provided by a user
class Feedback
{
    public string Content { get; set; } // The content of the feedback
    public string Category { get; set; } // The category of the feedback (e.g., Bug Report, Feature Request)

    // Constructor to initialize new feedback with content and category
    public Feedback(string content, string category)
    {
        Content = content; // Set the feedback content
        Category = category; // Set the feedback category
    }
}

namespace NSERSConsoleApp
{
    class Program
    {
        // Main instance of the incident reporting system
        static IncidentReportingSystem reportingSystem = new IncidentReportingSystem();
        // List of registered users
        static List<User> users = new List<User>
        {
            new User { Username = "Bill Liang", Password = "admin123" },
            new User { Username = "Lisa Li", Password = "pass123" },
            new User { Username = "Alex Wang", Password = "pass456" }
        };
        // List to hold all provided feedback
        static List<Feedback> feedbacks = new List<Feedback>();

        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Network Security Emergency Response System (NSERS) Console App!");

            // Authenticate the user before proceeding
            if (!AuthenticateUser()) return; // Exit if authentication fails

            bool running = true;
            while (running) // Keep the program running until the user chooses to exit
            {
                // Display the main menu and prompt the user for their choice
                Console.WriteLine("\nSelect an option:");
                Console.WriteLine("1. Report a security incident");
                Console.WriteLine("2. View all reported security incidents");
                Console.WriteLine("3. Real-time monitoring");
                Console.WriteLine("4. Automated incident response");
                Console.WriteLine("5. Provide feedback");
                Console.WriteLine("6. Exit");

                string choice = Console.ReadLine();

                // Handle the user's choice
                switch (choice)
                {
                    case "1":
                        ReportIncident();
                        break;
                    case "2":
                        ViewIncidents();
                        break;
                    case "3":
                        RealTimeMonitoring();
                        break;
                    case "4":
                        AutomatedResponse();
                        break;
                    case "5":
                        ProvideFeedback();
                        break;
                    case "6":
                        running = false; //Exit the application.
                        Console.WriteLine("Exiting NSERS Console App. Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
        // Authenticate the user with username and password
        static bool AuthenticateUser()
        {
            Console.WriteLine("Please enter your username:");
            string username = Console.ReadLine();
            Console.WriteLine("Please enter your password:");
            string password = Console.ReadLine();

            // Check if entered username and password match any user in the list
            if (users.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && u.Password == password))
            {
                Console.WriteLine("Authentication successful!");
                return true;
            }
            else
            {
                Console.WriteLine("Authentication failed. Access denied.");
                return false;
            }
        }

        // Prompt the user for incident details and severity, then report the incident
        static void ReportIncident()
        {
            Console.WriteLine("Please provide details of the security incident:");
            string details = Console.ReadLine();
            Console.WriteLine("Specify the severity (Low, Medium, High):");
            string severity = Console.ReadLine();

            // Check if the entered severity is valid before reporting the incident
            if (new[] { "Low", "Medium", "High" }.Contains(severity))
            {
                reportingSystem.ReportIncident(details, severity);
            }
            else
            {
                Console.WriteLine("Invalid severity. Incident not reported.");
            }
        }

        // Display all reported incidents
        static void ViewIncidents()
        {
            Console.WriteLine("All reported security incidents:");
            reportingSystem.DisplayIncidents();
        }

        // Simulate real-time monitoring and report an incident if detected
        static void RealTimeMonitoring()
        {
            Console.WriteLine("Real-time monitoring...");

            int numberOfChecks = 5;
            // Loop for a specified number of checks
            for (int i = 0; i < numberOfChecks; i++)
            {
                Console.WriteLine($"Checking for incidents... ({i + 1}/{numberOfChecks})");

                // Simulate different monitoring actions
                Thread.Sleep(500); // Simulate a brief pause to represent the monitoring action
                Console.WriteLine("   - Analyzing logs for unusual activities...");
                Thread.Sleep(500);
                Console.WriteLine("   - Monitoring network traffic for suspicious patterns...");
                Thread.Sleep(500);
                Console.WriteLine("   - Checking system performance metrics for anomalies...");
                Thread.Sleep(500);
                Console.WriteLine("   - Scanning other data sources for signs of security breaches...");

                if (i == numberOfChecks - 1)
                {
                    Console.WriteLine("Incident detected! Reporting...");
                    // Automatically report a detected incident
                    reportingSystem.ReportIncident("Incident detected during real-time monitoring.", "High");
                }
            }

            Console.WriteLine("Real-time monitoring complete.");
        }

        // Simulate automated response to an incident
        static void AutomatedResponse()
        {
            Console.WriteLine("Automated incident response...");

            // Execute a series of simulated steps for incident response
            Console.WriteLine("1. Isolating affected network segment...");
            Thread.Sleep(1000); // Simulate action with a delay
            Console.WriteLine("2. Notifying system administrators...");
            Thread.Sleep(1000);
            Console.WriteLine("3. Applying security patches...");
            Thread.Sleep(1000);
            Console.WriteLine("4. Logging the incident for further investigation...");
            Console.WriteLine("5. Conducting initial analysis and starting threat hunting activities...");
            Thread.Sleep(1000);
            Console.WriteLine("6. Communicating with stakeholders...");
            Thread.Sleep(1000);
            Console.WriteLine("7. Initiating recovery and system restoration...");
            Thread.Sleep(1000);
            Console.WriteLine("8. Conducting post-incident review and lessons learned session...");
            Thread.Sleep(1000);

            Console.WriteLine("Automated incident response complete. System administrators have been notified and will review the incident shortly.");
        }

        // Collect and categorize user feedback
        static void ProvideFeedback()
        {
            Console.WriteLine("Please enter your feedback below:");
            string feedbackContent = Console.ReadLine();
            Console.WriteLine("Specify the category of your feedback (Bug Report, Feature Request, Other):");
            string feedbackCategory = Console.ReadLine();

            // Validate feedback category before accepting
            if (new[] { "Bug Report", "Feature Request", "Other" }.Contains(feedbackCategory))
            {
                feedbacks.Add(new Feedback(feedbackContent, feedbackCategory));
                Console.WriteLine("Thank you for your feedback!");
            }
            else
            {
                Console.WriteLine("Invalid feedback category.");
            }
        }
    }
}

